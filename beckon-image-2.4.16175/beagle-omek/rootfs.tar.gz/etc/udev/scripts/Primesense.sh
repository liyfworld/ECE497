#!/bin/sh
#echo PrimeSense Camera Connected > /dev/tty0
cp /home/root/cameras/Primesense/libXnCore.so /usr/lib/
cp /home/root/cameras/Primesense/XnSensorServer /usr/bin/
