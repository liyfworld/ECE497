#!/bin/sh
#echo Kinect Camera Connected > /dev/tty0
cp /home/root/cameras/Kinect/libXnCore.so /usr/lib/
cp /home/root/cameras/Kinect/XnSensorServer /usr/bin/
