export LD_LIBRARY_PATH=/home/root/demo
sh /home/root/bin/reset-dsp.sh
