. ./setup.sh
cd demo
./GestureDemo $@
cd
