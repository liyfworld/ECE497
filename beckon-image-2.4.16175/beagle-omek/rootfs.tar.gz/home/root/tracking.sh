. ./setup.sh
cd demo
./QtTracking -qws $@ &> QtTracking_log.txt
clear
cd
