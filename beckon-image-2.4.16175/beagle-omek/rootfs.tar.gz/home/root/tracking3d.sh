. ./setup.sh
cd demo
./TrackingViewer3D $@ &> TrackingViewer3D_log.txt
clear
cd
